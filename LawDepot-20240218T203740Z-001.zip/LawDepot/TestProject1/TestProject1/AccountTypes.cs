﻿namespace testing.Enums
{
    public enum AccountTypes
    {
        standard_user,
        locked_out_user,
        problem_user,
        performance_glitch_user,
        error_user,
        visual_user
    }

    public enum Password
    {
        secret_sauce
    }
}
